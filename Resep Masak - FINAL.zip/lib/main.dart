import 'package:flutter/material.dart'; //import package yang diperlukan

void main() { //method utama untuk menjalankan program
  runApp(new MaterialApp(
    home: new Awal(), //tampilan home dengan class utama new awal
    title: "Resep Masak", //judul dari aplikasi yang dibuat
    routes: <String, WidgetBuilder>{ //routers digunakan untuk perpindahan ke halaman lain
      '/Awal' : (BuildContext context)=>new Awal(), //membuat class baru untuk halaman awal
      '/Daftar' : (BuildContext context)=>new Daftar(), // membuat class baru untuk halaman daftar
      '/Nusantara' : (BuildContext context)=>new Nusantara(), //membuat class baru untuk halaman nusantara
      '/Rumahan' : (BuildContext context)=>new Rumahan(), //membuat class baru untuk halaman rumahan
      '/Minuman' : (BuildContext context)=>new Minuman(), //membuat class baru untuk halaman minuman
      '/Gudeg' : (BuildContext context)=>new Gudeg(), //membuat class baru untuk halaman gudeg
      '/Keraktelor' : (BuildContext context)=>new Keraktelor(), //membuat class baru untuk halaman keraktelor
      '/Mieaceh' : (BuildContext context)=>new Mieaceh(), // membuat class baru untuk halaman mie aceh
      '/Pempek' : (BuildContext context)=>new Pempek(), // membuat class baru untuk halaman pempek
      '/Seruit' : (BuildContext context)=>new Seruit(), // membuat class baru untuk halaman seruit
      '/Capcay' : (BuildContext context)=>new Capcay(), // membuat class baru untuk halaman capcay
      '/Orektempe' : (BuildContext context)=>new Orektempe(), // membuat class baru untuk halaman orek tempe
      '/Sayurasem' : (BuildContext context)=>new Sayurasem(), // membuat class baru untuk halaman sayur asem
      '/Sayursop' : (BuildContext context)=>new Sayursop(),// membuat class baru untuk halaman sayur sop
      '/Terong' : (BuildContext context)=>new Terong(), // membuat class baru untuk halaman terong
      '/Bajigur' : (BuildContext context)=>new Bajigur(),// membuat class baru untuk halaman bajigur
      '/Cendol' : (BuildContext context)=>new Cendol(),// membuat class baru untuk halaman cendol
      '/Pisangijo' : (BuildContext context)=>new Pisangijo(),// membuat class baru untuk halaman pisang ijo
      '/Sekoteng' : (BuildContext context)=>new Sekoteng(),// membuat class baru untuk halaman sekoteng
      '/Wedang' : (BuildContext context)=>new Wedang(),// membuat class baru untuk halaman wedang
    },
  ));
}

//class utama
class Awal extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masak"), //membuat app bar dengan text resep masak
      centerTitle: true, //text atau judul app bar dengan posisi ditengah
      backgroundColor: Colors.pink,), //memberikan warna pink pada app bar
      body: Center( //posisi konten berada di tengah
        child: Column( //menambahkan widget dibagian child untuk menambahkan kolom
          mainAxisAlignment: MainAxisAlignment.center, //posisi kolom berapa ditengah
          children: <Widget>[
          Text(
          "Siap Untuk Masak ???", //menambahkan text
          style: TextStyle(fontSize: 40), //ukuran font 40
        ),
        Text(
          " ",
          style: TextStyle(fontSize: 20), //ukuran font 20
        ),
        Image( //menyisipkan foto
            fit: BoxFit.cover, //ukuran foto disesuai kan dengan cover
            image: AssetImage('images/nusantara.jpg',//memanggil foto pada folder images dengan nama foto nusantara.jpg
            )),
        FlatButton( //penambahan button atau tombol
          onPressed: () {
            Navigator.pushNamed(context, '/Daftar'); //navigasi saat tombol ditekan beralih pada class atau halaman daftar
          },
          color: Colors.blue, //warna tombol biru
          textColor: Colors.white, //warna text putih
          highlightColor: Colors.green, //ketika tombol ditekan memberikan highlight berwarna hijau
          child: Text(
            "Mulai",//text pada button
          ),
        ),
    ])
      ),
        );
  }
}

//class utama untuk daftar
class Daftar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masak"), //membuat app bar baru dengan judul resep masak
      centerTitle: true, //judul berada posisi tengah
      backgroundColor: Colors.pink,), //memerikan warna pada app bar
      body: new Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, //posisi konten berada ditengah
          children: <Widget>[
            Image( //memanggil foto
              width : 300, //ukuran foto 300px
                image: AssetImage('images/nusantara.jpg', //mengambil images dengan nama file nusantara.jpg
                )),
            FlatButton( //pemanggilan button atau tombol
              onPressed: () { //kondisi ketika tombol ditekan
                Navigator.pushNamed(context, '/Nusantara'); //navigasi ketika tombol ditekan berubah pada class atau halaman untuk nusantara
              },
              color: Colors.green, //warna button hijau
              textColor: Colors.white, //warna text putih
              highlightColor: Colors.brown, //highlight ketika tombol ditekan berwarna coklat
              child: Text(
                "Masakan Khas Nusantara", //text pada button
              ),
            ),
            Image( //memasukkan foto
              width: 300, //ukuran foto 300px
                image: AssetImage('images/warteg.jpg', //mangambil images dengan nama file warteg.jpg
                )),
            FlatButton( //membuat button atau tombol
              onPressed: () { //kondisi ketika button ditekan
                Navigator.pushNamed(context, '/Rumahan'); //saat button ditekan maka akan berpindah pada class atau halaman rumahan
              },
              color: Colors.green, //warna button hijau
              textColor: Colors.white, //text berwarna putih
              highlightColor: Colors.brown, //highlight ketika button ditekan berwarna coklat
              child: Text(
                "Masakan Rumah Sederhana", //text pada button
              ),
            ),
            Image( //menama=bahkan foto
              width: 300, //ukuran foto 300px
                image: AssetImage('images/minuman.jpg', //menmabahkan images dengan nama file minuman.jpg
                )),
            FlatButton( //membuat button atau tombol
              onPressed: () { //kondisi ketika tombol ditekan
                Navigator.pushNamed(context, '/Minuman'); //ketika tombol ditekan maka akan perpindah pada class atau halaman minuman
              },
              color: Colors.green, //warna tombol hijau
              textColor: Colors.white, //warna text putih
              highlightColor: Colors.brown, //highlight berwarna coklat
              child: Text(
                "Minuman", //text pada tombol
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//class utama nusantara
class Nusantara extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masak Khas Nusantara"), //membuat app bar baru
        centerTitle: true, //judul berada diposisi tengah
        backgroundColor: Colors.pink,), //background app bar berwarna pink
      body: SingleChildScrollView( //body konten memiliki class SingleChildScrollView, scroll dilakukan pada single widget
        child: Column(
          children: <Widget>[
            Align(alignment: Alignment(0, 0),), //posisi konten berada ditengah
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image( //menambahkan foto
              alignment: Alignment(0, 0), //posisi foto ditengah
                width : 300, //ukuran foto 300px
                image: AssetImage('images/gudeg.jpg', //menambahkan images dengan nama file gudeg.jpg
                )),
            FlatButton( //menambahkan button
              onPressed: () { //kondisi ketika button ditekan
                Navigator.pushNamed(context, '/Gudeg'); //ketika button ditekan akan dialihkan pada class atau halaman gudeg
              },
              color: Colors.green, //warna button hijau
              textColor: Colors.white, //warna text putih
              highlightColor: Colors.brown, //highlight ketika button ditekan berwarna coklat
              child: Text(
                "Gudeg - Jawa Tengah", //text pada button
              ),
            ),
            Image( //menambahkan images
                width: 300, //ukuran images 300px
                image: AssetImage('images/kerak telor.jpg', //menambahkan images dengan nama file kerak telor.jpg
                )),
            FlatButton( //menambahkan button
              onPressed: () { //kondisi ketika button ditekan
                Navigator.pushNamed(context, '/Keraktelor'); //ketika button ditekan akan dialihkan pada class atau halaman keraktelor
              },
              color: Colors.green, //butto berwarna hijau
              textColor: Colors.white, //text berwarna putih
              highlightColor: Colors.brown, //highlight ketika button ditekan berwarna coklat
              child: Text(
                "Kerak Telor - Jakarta", //text pada button
              ),
            ),
            Image( //menambahkan images
                width: 300, //images berukuran 300px
                image: AssetImage('images/mie aceh.jpg', //menambahkan images dengan nama file mie aceh.jpg
                )),
            FlatButton( //menambahkan button
              onPressed: () { //kondisi ketika button ditekan
                Navigator.pushNamed(context, '/Mieaceh'); //ketika button ditekan maka akan dialihkan pada class atau halaman mieaceh
              },
              color: Colors.green,  //button berwarna hijau
              textColor: Colors.white, //text berawrna putih
              highlightColor: Colors.brown, //highlight ketika button ditekan berawrna coklat
              child: Text(
                "Mie Aceh - Aceh", //text pada button
              ),
            ),
            Image(
                width: 300,
                image: AssetImage('images/pempek.jpg',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Pempek');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Pempek - Palembang",
              ),
            ),
            Image(
                width: 300,
                image: AssetImage('images/seruit.jpg',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Seruit');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Seruit - Lampung",
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Rumahan extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masak Rumahan"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                width: 300,
                image: AssetImage('images/capcay.jpg',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Capcay');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Capcay",
              ),
            ),
            Image(
                width: 300,
                image: AssetImage('images/orek tempe.jpg',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Orektempe');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Orek Tempe",
              ),
            ),
            Image(
                width: 300,
                image: AssetImage('images/sy asem.jpg',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Sayurasem');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Sayur Asem",
              ),
            ),
            Image(
                width: 300,
                image: AssetImage('images/sy sop.jpg',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Sayursop');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Sayur Sop",
              ),
            ),
            Image(
                width: 300,
                image: AssetImage('images/terong.jpg',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Terong');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Terong Balado",
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Minuman extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Minuman"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                alignment: Alignment(0, 0),
                width : 300,
                image: AssetImage('images/bajigur.jpg',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Bajigur');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Bajigur",
              ),
            ),
            Image(
                width: 300,
                image: AssetImage('images/cendol.jpg',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Cendol');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Es Cendol",
              ),
            ),
            Image(
                width: 300,
                image: AssetImage('images/pisjo.png',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Pisangijo');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Es Pisang Ijo",
              ),
            ),
            Image(
                width: 300,
                image: AssetImage('images/sekoteng.jpg',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Sekoteng');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Sekoteng",
              ),
            ),
            Image(
                width: 300,
                image: AssetImage('images/wedang.jpg',
                )),
            FlatButton(
              onPressed: () {
                Navigator.pushNamed(context, '/Wedang');
              },
              color: Colors.green,
              textColor: Colors.white,
              highlightColor: Colors.brown,
              child: Text(
                "Wedang Jahe",
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//class utama gudeg
class Gudeg extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masak Gudeg Khas Jawa Tengah"), //membuat app baru baru
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30), //padding 30 diseluruh sisi tepi konten
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly, //spasi yg dilakukan setelah maupun sebelum children
          children: <Widget>[
            Align(alignment: Alignment(0, 0),), //posisi konten ditengah
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/gudeg.jpg',
                )),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('1/2 kg nangka muda'),
            Text ('6 butir telur rebus (secukupnya)'),
            Text (" "),
            Text ('Bumbu halus :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('5 buah bawang merah'),
            Text ('2 buah bawang putih'),
            Text ('5 butir kemiri'),
            Text (" "),
            Text ('Bumbu campuran :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('4 lembar daun salam'),
            Text ('Lengkuas secukupnya'),
            Text ('2 batang serai'),
            Text ('1 butir gula aren (iris)'),
            Text ('1 bungkus santan kemasan'),
            Text ('Garam secukupnya'),
            Text ('Penyedap rasa secukupnya'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Uleg bumbu halus'),
            Text ('Cuci bersih nangka yang sudah direbus'),
            Text ('Masukkan bumbu lainnya ke dalam wajan, kemudian bumbu halus dan terakhir nangka', textAlign: TextAlign.center,),
            Text ('Masukkan santan'),
            Text ('Masak dengan api sedang'),
            Text ('Ketika air sudah surut maka masukkan telur rebus, gula aren, garam, dan penyedap rasa', textAlign: TextAlign.center,),
            Text ('Jika rasa sudah pas maka gudeg siap disajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],

        ),
      ),
    );
  }
}

class Keraktelor extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masak Kerak Telor Khas Betawi"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/kerak telor.jpg',
                )),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text (" "),
            Text ('Bahan kelapa rebon :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('1/2 butir kelapa parut, sangrai hingga kering'),
            Text ('2 sdm udang rebon kering'),
            Text ('1 sdm gula pasir'),
            Text ('1/2 sdt kaldu jamur bubuk'),
            Text (" "),
            Text ('Bumbu basah :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('1 butir telur'),
            Text ('1/2 sdt bumbu halus (bawang merah dan bawang putih)'),
            Text ('2-3 sdm nasi putih'),
            Text ('Garam secukupnya'),
            Text ('Lada secukupnya'),
            Text ('Penyedap rasa secukupnya'),
            Text (" "),
            Text ('Topping :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Bawang goreng'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Uleg bahan kelapa rebon, kemudian sisihkan'),
            Text ('Kocok telur, nasi, garam, lada, penyedap rasa, bumbu halus, dan 2 sdt bubuk kelapa rebon hingga rata', textAlign: TextAlign.center,),
            Text ('Tuangkan ke atas teflon anti lengket, masak hingga bagian bawah kecoklatan, kemudian di balik', textAlign: TextAlign.center,),
            Text ('Jika dirasa sudah matang nagkat, taburi dengan bubuk kelapa rebon, dan bawang goreng', textAlign: TextAlign.center,),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Mieaceh extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masak Mie Aceh Khas Aceh"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/mie aceh.jpg',
                )),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('1 bungkus mie telur'),
            Text ('100 gram udang yang sudah dibersihkan'),
            Text ('30 gram kol'),
            Text ('Toge secukupnya'),
            Text ('1 batang daun bawang'),
            Text ('1/2 buah tomat'),
            Text ('2 buah bawang putih'),
            Text ('4 buah bawang merah'),
            Text ('1 sdt bubuk kari'),
            Text ('Kecap manis secukupnya'),
            Text ('Lada, garam, gula pasir, penyedap rasa secukupnya'),
            Text ('Air secukupnya'),
            Text (" "),
            Text ('Bumbu halus :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('5 buah bawang merah'),
            Text ('2 buah bawang putih'),
            Text ('4 buah cabai merah (sesuai selera)'),
            Text ('2 buah kapulaga'),
            Text ('1/4 sdt jinten'),
            Text ('2 cm kunyit'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Rebus mie hingga empuk'),
            Text ('Potong - potong bawang merah, bawang putih, daun bawang, tomat dan kol',textAlign: TextAlign.center,),
            Text ('Haluskan semua bumbu halus'),
            Text ('Panaskan minyak, tumis bawang merah dan bawang putih hingga harum. Lalu masukkan bumbu halus, tumis hingga matang', textAlign: TextAlign.center,),
            Text ('Masukkan udang, kol, toge, dan tomat. Masak hingga layu dan udang berubah warna',textAlign: TextAlign.center,),
            Text ('Masukkan mie, daun bawang, bubuk kari, kecap, lada, garam, gula pasir, dan penyedap rasa. Masak hingga rata', textAlign: TextAlign.center,),
            Text ('Jika dirasa sudah matang angkat dan sajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Pempek extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masak Pempek Khas Palembang"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/pempek.jpg',
                )),
            Text(" "),
            Text('Bahan - Bahan :',
                style: TextStyle(fontWeight: FontWeight.bold)),
            Text('800 gram tepung tapioka/sagu'),
            Text('60 gram tepung terigu'),
            Text('400 gram ikan tenggiri (haluskan)'),
            Text('Gula pasir secukupnya'),
            Text('Garam secukupnya'),
            Text('Kecap manis secukupnya'),
            Text('Gula jawa secukupnya'),
            Text('Penyedap rasa secukupnya'),
            Text('telur ayam secukupnya'),
            Text('9 buah bawang putih'),
            Text('100 gram asam jawa'),
            Text('6 buah cabai rawit (sesuai selera)'),
            Text('50 gram ebi'),
            Text('Mie kuning secukupnya'),
            Text('Timun secukupnya'),
            Text('Air secukupnya'),
            Text(" "),
            Text('Langkah Pembuatan :', style: TextStyle(fontWeight: FontWeight.bold)),
            Text('Blender ikan tenggiri dan 5 buah bawang putih'),
            Text('Masukkan 400 ml air dan 60gram tepung terigu, masak hingga tercampur. Kemudian dinginkan',textAlign: TextAlign.center,),
            Text('Setelah adonan tepung dingin, masukkan ikan tenggiri, garam, gula pasir dan penyedap rasa. Lalu aduk hingga rata',textAlign: TextAlign.center,),
            Text('Masukkan tepung tapioka sedikit demi sedikit dan terus diaduk'),
            Text('Bentuk adonan sesuai selera, untuk pempek kapal selam masukkan telur ayam yang telah dikocok secukupnya lalu tutup rapat',textAlign: TextAlign.center,),
            Text('Siapkan air untuk merebus. Ketika mendidih masukkan adonan dan tunggu hingga mengapung', textAlign: TextAlign.center,),
            Text('Untuk bumbu cuko, uleg cabai, 4 buah bawang putih, dan ebi hingga halus',textAlign: TextAlign.center,),
            Text('Rebus air bersama asam jawa, gula jawa, dan sedikit kecap hingga mendidih',textAlign: TextAlign.center,),
            Text('Tambahkan bumbu yang telah dihaluskan'),
            Text('Goreng pempek yang telah direbus. Sajikan dengan mie kuning, timun, dan cuko secukupnya',textAlign: TextAlign.center,),
            Text(" "),
            Text('SELAMAT MENCOBA DI RUMAH', style: TextStyle(
                fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Seruit extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masak Seruit Khas Lampung"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/seruit.jpg',
                )),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('2 ekor ikan cakalang (ikan sesuai selera) bersihkan'),
            Text ('3 buah bawang merah'),
            Text ('2 buah bawang putih'),
            Text ('2 buah tomat'),
            Text ('1 ruas kencur'),
            Text ('Cabai rawit sesuai selera'),
            Text ('Garam secukupnya'),
            Text ('Penyedap rasa secukupnya'),
            Text ('Jeruk nipis secukupnya'),
            Text ('Lalapan sesuai selera'),
            Text (" "),
            Text ('Bumbu perendam :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('1 bungkus bawang putih bubuk'),
            Text ('1/2 sdt kunyit bubuk'),
            Text ('Perasan air jeruk nipis secukupnya'),
            Text ('Garam secukupnya'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Taburi ikan dengan bumbu perendam yang telah dihaluskan'),
            Text ('Bakar ikan hingga matang. Jangan lupa di bolak - balik'),
            Text ('Uleg bawang merah, bawang putih, kencur, garam, cabai, penyedap rasa, dan tomat',textAlign: TextAlign.center,),
            Text ('Penyetkan ikan yang sudah makan di atas sambal dan taburi perasan jeruk nipis',textAlign: TextAlign.center,),
            Text ('Sajikan dengan nasi hangat dan lalapan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],

        ),
      ),
    );
  }
}

class Capcay extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masakan Rumahan Capcay"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/capcay.jpg',
                )),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('150 gram wortel'),
            Text ('150 gram kol putih'),
            Text ('150 gram brokoli'),
            Text ('150 gram sawi putih'),
            Text ('50 gram bawang bombay'),
            Text ('4 buah bawang putih'),
            Text ('6 bakso sapi (bakso sesuai selera)'),
            Text ('200 ml air'),
            Text ('3 sdm minyak goreng'),
            Text ('Penyedap rasa secukupnya'),
            Text ('Saus tiram secukupnya'),
            Text ('Lada secukupnya'),
            Text ('1 sdt gula pasir'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Potong sayuran (wortel, kol, brokoli dan sawi putih) sesuai selera. Potong bawang bombay beukuran dadu',textAlign: TextAlign.center,),
            Text ('Memarkan bawang putih, kemudian tumis bersama bawang bombay hingga harum',textAlign: TextAlign.center,),
            Text ('Masukkan bakso, sayuran, penyedap rasa, lada, saus tiram dan gula pasir. Kemudian aduk hingga rata',textAlign: TextAlign.center,),
            Text ('Masak hingga kuah mengental'),
            Text ('Jika dirasa sudah matang, angkat dan sajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],

        ),
      ),
    );
  }
}

class Orektempe extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masakan Rumahan Orek Tempe"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/orek tempe.jpg',
                )),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('250 gram tempe'),
            Text ('25 gram cabai (sesuai selera)'),
            Text ('1 buah bawang putih'),
            Text ('2 buah bawang merah'),
            Text ('Lengkuas 2 cm'),
            Text ('2 lembar daun salam'),
            Text ('Penyedap rasa secukupnya'),
            Text ('kecap manis secukupnya'),
            Text ('Minyak goreng'),
            Text ('Air secukupnya'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Potong tempe sesuai selera, kemudian goreng setengah matang lalu tiriskan',textAlign: TextAlign.center,),
            Text ('Potong cabai, iris tipis bawang putih dan bawang merah'),
            Text ('Panaskan minyak, lalu tumis bawang putih dan bawang merah hingga harum',textAlign: TextAlign.center,),
            Text ('Tambahkan lengkuas, daun salam, serta cabai, lalu aduk rata'),
            Text ('Masukkan tempe yang sudah digoreng, penyedap rasa, kecap manis, dan tambahkan air secukupnya',textAlign: TextAlign.center,),
            Text ('Jika dirasa sudah matang, angkat dan sajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Sayurasem extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masakan Rumahan Sayur Asem"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/sy asem.jpg',
                )),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('500 ml air'),
            Text ('100 gram melinjo'),
            Text ('100 gram kacang tanah'),
            Text ('1 buah jagung manis'),
            Text ('Labu siam secukupnya'),
            Text ('100 gram kacang panjang'),
            Text ('50 gram daun melinjo'),
            Text ('2 buah bawang putih'),
            Text ('4 buah bawang merah'),
            Text ('3 cm lengkuas'),
            Text ('3 cabai merah (sesuai selera)'),
            Text ('Gula pasir secukupnya'),
            Text ('Garam secukupnya'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Potong jagung manis, kacang panjang, dan labu siam sesuai dengan selera',textAlign: TextAlign.center,),
            Text ('Haluskan bawang putih, bawang merah, dan cabai'),
            Text ('Rebus air hingga mendidih, masukkan bumbu yang telah dihaluskan, dan lengkuas',textAlign: TextAlign.center,),
            Text ('Tambahkan kacang tanah, melinjo dan jagung manis. Masak hingga setengah matang',textAlign: TextAlign.center,),
            Text ('Masukkan labu siam, kacang panjang, dan daun melinjo. Tambahkan garam dan gula. Aduk rata',textAlign: TextAlign.center,),
            Text ('Jika dirasa sudah matang, angkat dan sajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Sayursop extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masakan Rumahan Sayur Sop"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/sy sop.jpg',
                )),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('1/2 ekor ayam, potong 4 bagian'),
            Text ('100 gram wortel'),
            Text ('100 gram kentang'),
            Text ('100 gram buncis'),
            Text ('2 lembar seledri'),
            Text ('2 lembar daun bawang'),
            Text ('1.5 l air'),
            Text ('Penyedap rasa secukupnya'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Potong wortel, kentang, dan buncis sesuai dengan selera. Lalu iris daun bawang dan daun seledri',textAlign: TextAlign.center,),
            Text ('Rebus ayam hingga empuk dengan api sedang'),
            Text ('Masukkan wortel, kentang, dan buncis. Masak dengan api kecil'),
            Text ('Tambahkan penyedap rasa secukupnya. Lalu masukkan daun bawang dan daun seledri',textAlign: TextAlign.center,),
            Text ('Jika dirasa sudah matang, angkat dan sajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Terong extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Masakan Rumahan Terong Balado"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/terong.jpg',
                )),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('5 buah terong'),
            Text ('100 gram cabai kriting'),
            Text ('5 buah bawang merah'),
            Text ('1 buah kemiri'),
            Text ('2 cm lengkuas'),
            Text ('1 buah tomat tanpa biji'),
            Text ('Gula pasir secukupnya'),
            Text ('Penyedap rasa secukupnya'),
            Text ('Minyak goreng secukupnya'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Potong terong sesuai selera'),
            Text ('Haluskan bawang merah, cabai kriting, kemiri, dan gula pasir'),
            Text ('Panaskan minyak goreng, tumis bumbu yang telah dihaluskan dan lengkuas yang sudah dimemarkan',textAlign: TextAlign.center,),
            Text ('Tambahkan terong dan penyedap rasa. Aduk rata hingga matang'),
            Text ('Jika dirasa sudah matang, angkat dan sajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Bajigur extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Minuman Bajigur"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/bajigur.jpg',)),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('600 ml air'),
            Text ('2 lembar daun pandan'),
            Text ('2 batang kayu manis'),
            Text ('50 gram jahe merah'),
            Text ('100 gram gula jawa'),
            Text ('Gula pasir secukupnya'),
            Text ('100 ml santan'),
            Text ('200 ml air'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Rebus daun pandan, kayu manis, jahe merah, dan gula jawa hingga mendidih',textAlign: TextAlign.center,),
            Text ('Rebus 200 ml air bersama santan hingga mengental'),
            Text ('Siapkan gelas, tuang air rebusan jahe merah lalu masukkan santan',textAlign: TextAlign.center,),
            Text ('Bajigur siap disajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Cendol extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Minuman Bajigur"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/cendol.jpg',)),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('500 gram es batu'),
            Text (" "),
            Text ('Bahan Cendol :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('150 gram tepung beras'),
            Text ('1 sdm tepung kanji'),
            Text ('500 ml air'),
            Text ('50 ml air suji'),
            Text ('1 sdt garam'),
            Text ('Pewarna makanan hijau tua'),
            Text (" "),
            Text ('Bahan Sirup :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('200 gram gula merah'),
            Text ('150 ml air'),
            Text ('2 lembar daun pandan'),
            Text (" "),
            Text ('Bahan Kuah Santan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('400 ml santan'),
            Text ('2 lembar daun pandan'),
            Text ('1/4 sdt garam'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Larutkan tepung beras, air suji, garam, dan 2 tetes pewarna makanan hijau tua',textAlign: TextAlign.center,),
            Text ('Masak hingga kalis. Kemudian masukkan ke cetakan cendol'),
            Text ('Untuk sirup, didihkan gula merah, air, daun pandan, dan garam hingga kental',textAlign: TextAlign.center,),
            Text ('Untuk kuah santan, rebus santan, garam dan daun pandan hingga mendidih',textAlign: TextAlign.center,),
            Text ('Siapkan gelas berisi es batu, masukkan cendol, sirup, dan kuah santan',textAlign: TextAlign.center,),
            Text ('Es Cendol siap disajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Pisangijo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Minuman Bajigur"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
              width: 800,
                image: AssetImage('images/pisjo.png',)),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text (" "),
            Text ('Bahan Pisang Ijo :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('2 buah pisang raja yang dikukus'),
            Text ('200 gram tepung beras'),
            Text ('2 sdt tepung kanji'),
            Text ('700 ml santan'),
            Text ('50 gram gula pasir'),
            Text ('Pewarna makanan hijau tua'),
            Text ('Daun pisang'),
            Text (" "),
            Text ('Bahan Bubur Sumsum :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('200 ml santan'),
            Text ('100 gram tepung beras'),
            Text ('2 sdt garam'),
            Text (" "),
            Text ('Bahan Pelengkap :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Sirup cocopandan secukupnya (sirup sesuai selera)'),
            Text ('Susu putih kental manis secukupnya'),
            Text ('Es batu secukupnya'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Untuk pisang ijo, didihkan santan, tepung beras, tepung kanji, gula pasir dan pewarna makanan hingga kental',textAlign: TextAlign.center,),
            Text ('Tuangkan adonan di daun pisang, letakkan pisang ditengah adonan, gulung daun pisang, dan kukus hingga matang',textAlign: TextAlign.center,),
            Text ('Untuk bubur sumsum, panaskan santan, tepung beras, dan garam. Aduk hingga mengental',textAlign: TextAlign.center,),
            Text ('Siapkan gelas/mangkuk berisi es batu, masukkan potongan pisang ijo, bubur sumsum, sirup, dan susu kental manis',textAlign: TextAlign.center,),
            Text ('Es Pisang Ijo siap disajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Sekoteng extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Minuman Sekoteng"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/sekoteng.jpg',)),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('100 ml air'),
            Text ('50 gram gula pasir'),
            Text ('50 gram gula jawa'),
            Text ('50 gram jahe merah'),
            Text ('1 lembar daun pandan'),
            Text ('4 buah cengkeh'),
            Text ('3 cm kayu manis'),
            Text (" "),
            Text ('Bahan Isi :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('2 lembar roti tawar'),
            Text ('Susu putih kental manis secukupnya'),
            Text ('50 gram kacang tanah sangrai'),
            Text ('50 gram kacang hijau rebus'),
            Text ('50 gram kolang-kaling rebus'),
            Text ('50 gram pacar cina rebus'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Rebus air bersama gula, jahe, daun pandan, cengkeh dan kayu manis hingga mendidih',textAlign: TextAlign.center,),
            Text ('Siapkan mangkuk, kemudian masukkan pacar cina, kolang-kaling, kacang hijau, kacang tanah dan roti tawar',textAlign: TextAlign.center,),
            Text ('Tuangkan air rebusan jahe ke dalam mangkuk'),
            Text ('Sekoteng siap disajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Wedang extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Resep Minuman Wedang Jahe"),
        centerTitle: true,
        backgroundColor: Colors.pink,),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column (
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Align(alignment: Alignment(0, 0),),
            Text(
              " ",
              style: TextStyle(fontSize: 20),
            ),
            Image(
                image: AssetImage('images/wedang.jpg',)),
            Text (" "),
            Text ('Bahan - Bahan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('2 gelas air'),
            Text ('2 rimpe jahe'),
            Text ('7 cm kayu manis'),
            Text ('1 batang serai'),
            Text ('Madu secukupnya'),
            Text (" "),
            Text ('Langkah Pembuatan :', style : TextStyle(fontWeight:FontWeight.bold)),
            Text ('Pertama - tama geprek jahe dan serai'),
            Text ('Rebus bahan - bahan dengan api sedang selama 15 menit hingga mendidih',textAlign: TextAlign.center,),
            Text ('Siapkan gelas, tuangkan air rebusan jahe kemudian tuangkan madu sesuai selera',textAlign: TextAlign.center,),
            Text ('Wedang Jahe siap disajikan'),
            Text (" "),
            Text ('SELAMAT MENCOBA DI RUMAH', style : TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}